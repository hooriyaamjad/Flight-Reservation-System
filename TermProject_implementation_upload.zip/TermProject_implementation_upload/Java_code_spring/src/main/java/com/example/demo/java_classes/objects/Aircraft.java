package com.example.demo.java_classes.objects;

public class Aircraft {

    private String name;

    public Aircraft(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String new_name) {
        this.name = new_name;
    }

}
